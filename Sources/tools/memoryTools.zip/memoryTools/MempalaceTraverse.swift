//
//  MempalaceTraverse.swift
//
//
//  Created by Ethan Brown on 4/28/26.
//

import Foundation

class MempalaceTraverse: Tool {
    static let name = "mempalace_traverse"
    
    func openAISchema() -> [String : Any] {
        return [
            "type": "function",
            "name": MempalaceTraverse.name,
            "description": """
            Walk the palace graph from a room. Shows connected ideas across wings — the tunnels. Like following a thread through the palace: start at 'chromadb‑setup' in wing_code, discover it connects to wing_myproject (planning) and wing_user (feelings about it).
            """,
            "parameters": [
                "type": "object",
                "properties": [
                    "start_room": [
                        "type": "string",
                        "description": "Room to start from (e.g. 'chromadb-setup', 'riley-school')"
                    ],
                    "max_hops": [
                        "type": "integer",
                        "description": "How many connections to follow (default: 2)",
                        "default": 2
                    ]
                ],
                "required": ["start_room"]
            ]
        ]
    }

    func anthropicSchema() -> [String : Any] {
        return [
            "name": MempalaceTraverse.name,
            "description": """
            Walk the palace graph from a room. Shows connected ideas across wings — the tunnels. Like following a thread through the palace: start at 'chromadb‑setup' in wing_code, discover it connects to wing_myproject (planning) and wing_user (feelings about it).
            """,
            "input_schema": [
                "type": "object",
                "properties": [
                    "start_room": [
                        "type": "string",
                        "description": "Room to start from (e.g. 'chromadb-setup', 'riley-school')"
                    ],
                    "max_hops": [
                        "type": "integer",
                        "description": "How many connections to follow (default: 2)",
                        "default": 2
                    ]
                ],
                "required": ["start_room"]
            ]
        ]
    }
    
    func ollamaSchema() -> [String: Any] {
        return [
            "type": "function",
            "function": [
                "name": MempalaceTraverse.name,
                "description": "Walk the palace graph from a room. Shows connected ideas across wings — the tunnels. Like following a thread through the palace: start at 'chromadb-setup' in wing_code, discover it connects to wing_myproject (planning) and wing_user (feelings about it).",
                "parameters": [
                    "type": "object",
                    "required": ["start_room"],
                    "properties": [
                        "start_room": [
                            "type": "string",
                            "description": "Room to start from (e.g. 'chromadb-setup', 'riley-school')"
                        ],
                        "max_hops": [
                            "type": "integer",
                            "description": "How many connections to follow (default: 2)"
                        ]
                    ]
                ]
            ]
        ]
    }
    
    func execute(args: [String: Any]) async -> String {
        return await MempalaceMemory.shared.mempalaceExec(name: MempalaceTraverse.name, args: args)
    }
}

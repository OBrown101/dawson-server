//
//  MempalaceCheckDuplicate.swift
//
//
//  Created by Ethan Brown on 4/28/26.
//

import Foundation

class MempalaceCheckDuplicate: Tool {
    static let name = "mempalace_check_duplicate"
    
    func openAISchema() -> [String : Any] {
        return [
            "type": "function",
            "name": MempalaceCheckDuplicate.name,
            "description": "Check if content already exists in the palace before filing",
            "parameters": [
                "type": "object",
                "properties": [
                    "content": [
                        "type": "string",
                        "description": "Content to check"
                    ],
                    "threshold": [
                        "type": "number",
                        "description": "Similarity threshold 0‑1 (default 0.9)",
                        "default": 0.9
                    ]
                ],
                "required": ["content"]
            ]
        ]
    }
    
    func anthropicSchema() -> [String : Any] {
        return [
            "name": MempalaceCheckDuplicate.name,
            "description": "Check if content already exists in the palace before filing",
            "input_schema": [
                "type": "object",
                "properties": [
                    "content": [
                        "type": "string",
                        "description": "Content to check"
                    ],
                    "threshold": [
                        "type": "number",
                        "description": "Similarity threshold 0‑1 (default 0.9)",
                        "default": 0.9
                    ]
                ],
                "required": ["content"]
            ]
        ]
    }
    
    func ollamaSchema() -> [String: Any] {
        return [
            "type": "function",
            "function": [
                "name": MempalaceCheckDuplicate.name,
                "description": "Check if content already exists in the palace before filing",
                "parameters": [
                    "type": "object",
                    "required": ["content"],
                    "properties": [
                        "content": [
                            "type": "string",
                            "description": "Content to check"
                        ],
                        "threshold": [
                            "type": "number",
                            "description": "Similarity threshold 0-1 (default 0.9)"
                        ]
                    ]
                ]
            ]
        ]
    }
    
    func execute(args: [String: Any]) async -> String {
        return await MempalaceMemory.shared.mempalaceExec(name: MempalaceCheckDuplicate.name, args: args)
    }
}
